document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("donorForm");
    const consentCheckbox = document.getElementById("consent");
    const organSection = document.getElementById("organ-section");
    const selectAllCheckbox = document.getElementById("selectAll");
    const modal = document.getElementById("confirmationModal");
    const cancelBtn = document.getElementById("cancelBtn");
    const confirmBtn = document.getElementById("confirmBtn");
  
    // Set max date for DOB (must be 18+)
    const dobInput = document.getElementById("dob");
    const today = new Date();
    const minDate = new Date(today.getFullYear() - 100, today.getMonth(), today.getDate());
    const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
    dobInput.max = maxDate.toISOString().split("T")[0];
    dobInput.min = minDate.toISOString().split("T")[0];
  
    // Auto-format phone number
    const phoneInput = document.getElementById("phone");
    phoneInput.addEventListener("input", (e) => {
      const numbers = e.target.value.replace(/\D/g, "");
      const char = { 0: "(", 3: ") ", 6: "-" };
      let formatted = "";
      for (let i = 0; i < numbers.length; i++) {
        formatted += (char[i] || "") + numbers[i];
      }
      e.target.value = formatted.substring(0, 14);
    });
  
    // Show organ selection when consent is given
    consentCheckbox.addEventListener("change", () => {
      organSection.classList.toggle("hidden", !consentCheckbox.checked);
    });
  
    // Select All Organs
    selectAllCheckbox.addEventListener("change", () => {
      const checkboxes = document.querySelectorAll("#organ-section input[type='checkbox']:not(#selectAll)");
      checkboxes.forEach(checkbox => {
        checkbox.checked = selectAllCheckbox.checked;
      });
    });
  
    // Real-time validation
    form.addEventListener("input", (e) => {
      validateField(e.target);
    });
  
    // Form submission with modal confirmation
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (validateForm()) {
        modal.classList.remove("hidden");
      }
    });
  
    // Modal controls
    cancelBtn.addEventListener("click", () => {
      modal.classList.add("hidden");
    });
  
    confirmBtn.addEventListener("click", () => {
      alert("Registration submitted successfully!");
      form.reset();
      modal.classList.add("hidden");
      // In a real app: Send data to server here
    });
  
    // Field validation
    function validateField(field) {
      const errorElement = field.nextElementSibling;
      if (!errorElement || !errorElement.classList.contains("error-message")) return;
  
      errorElement.textContent = "";
      errorElement.style.display = "none";
  
      if (field.required && !field.value.trim()) {
        errorElement.textContent = "This field is required";
        errorElement.style.display = "block";
        return false;
      }
  
      if (field.type === "email" && !/^\S+@\S+\.\S+$/.test(field.value)) {
        errorElement.textContent = "Please enter a valid email";
        errorElement.style.display = "block";
        return false;
      }
  
      if (field.id === "phone" && field.value.replace(/\D/g, "").length < 10) {
        errorElement.textContent = "Please enter a valid phone number";
        errorElement.style.display = "block";
        return false;
      }
  
      if (field.id === "zip" && !/^\d{5}$/.test(field.value)) {
        errorElement.textContent = "Please enter a 5-digit ZIP code";
        errorElement.style.display = "block";
        return false;
      }
  
      return true;
    }
  
    // Full form validation
    function validateForm() {
      let isValid = true;
      const requiredFields = form.querySelectorAll("[required]");
  
      requiredFields.forEach(field => {
        if (!validateField(field)) isValid = false;
      });
  
      // Check if at least one organ is selected (if consent given)
      if (consentCheckbox.checked) {
        const organsSelected = document.querySelectorAll("#organ-section input[type='checkbox']:checked").length > 0;
        if (!organsSelected) {
          const errorElement = organSection.querySelector(".error-message");
          errorElement.textContent = "Please select at least one organ/tissue";
          errorElement.style.display = "block";
          isValid = false;
        }
      }
  
      return isValid;
    }
  
    // Save form data to localStorage periodically
    setInterval(() => {
      const formData = new FormData(form);
      const formObject = Object.fromEntries(formData.entries());
      localStorage.setItem("donorFormDraft", JSON.stringify(formObject));
    }, 5000);
  
    // Load draft from localStorage
    const savedDraft = localStorage.getItem("donorFormDraft");
    if (savedDraft) {
      const draft = JSON.parse(savedDraft);
      for (const key in draft) {
        const field = form.querySelector(`[name="${key}"]`);
        if (field) {
          if (field.type === "checkbox") {
            field.checked = draft[key] === "on";
          } else {
            field.value = draft[key];
          }
        }
      }
      if (draft.consent === "on") organSection.classList.remove("hidden");
    }
  });

  let slideIndex = 0;

  function showSlides() {
      let slides = document.getElementsByClassName("mySlides");
  
      for (let i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";
      }
  
      slideIndex++;
      if (slideIndex > slides.length) { slideIndex = 1; }
      
      slides[slideIndex - 1].style.display = "block";
  
      setTimeout(showSlides, 5000); // Change slide every 5 seconds
  }
  
  function plusSlides(n) {
      slideIndex += n;
      let slides = document.getElementsByClassName("mySlides");
  
      if (slideIndex > slides.length) { slideIndex = 1; }
      if (slideIndex < 1) { slideIndex = slides.length; }
  
      for (let i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";
      }
      slides[slideIndex - 1].style.display = "block";
  }
  
  // Initialize slideshow on page load
  document.addEventListener("DOMContentLoaded", function() {
      showSlides();
  });
  